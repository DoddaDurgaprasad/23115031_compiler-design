#include "parser.h"
#include <stdexcept>

bool parseTokens(const std::vector<int>& tokens) {
    return tokens.size() == 2;
}
