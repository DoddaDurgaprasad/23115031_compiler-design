#pragma once
#include <string>

std::string generateThreeAddressCode(int a, int b);
