#include "ir.h"

std::string generateThreeAddressCode(int a, int b) {
    return "t1 = " + std::to_string(a) + " * " + std::to_string(a) + " * " + std::to_string(a) + "\n" +
           "t2 = " + std::to_string(b) + " * " + std::to_string(b) + " * " + std::to_string(b) + "\n" +
           "t3 = t1 + t2";
}
