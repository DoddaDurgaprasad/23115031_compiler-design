#pragma once
#include <vector>

bool parseTokens(const std::vector<int>& tokens);
