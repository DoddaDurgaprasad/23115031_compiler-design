#pragma once
#include <string>

int computeSumOfCubes(int a, int b);
std::string generateAssemblyCode(int a, int b);
