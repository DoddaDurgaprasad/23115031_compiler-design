#include "lexer.h"
#include <sstream>

std::vector<int> lexer(const std::string& input) {
    std::vector<int> tokens;
    std::stringstream ss(input);
    int num;
    while (ss >> num) {
        tokens.push_back(num);
    }
    return tokens;
}
