#include "semantic.h"
#include <stdexcept>

bool semanticCheck(const std::vector<int>& tokens) {
    for (int token : tokens) {
        if (token < 0) return false;
    }
    return true;
}
